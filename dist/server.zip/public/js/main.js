$(document).ready(function () {
    // Place JavaScript code here...
});
//# sourceMappingURL=main.js.map